import React, {useEffect, useMemo, useState} from 'react';
import {createRoot} from 'react-dom/client';
import {Download, Search, BookOpen, ShieldCheck, ArrowLeft, FileText, Archive, Sparkles, X, Pencil, Save, Upload, Database, LogIn, LogOut, Cloud, LockKeyhole} from 'lucide-react';
import './styles.css';
import {supabase, supabaseConfigured} from './lib/supabase';

const data = await fetch('/models.json').then(r=>r.json());
const zipUrl = '/quran-exams.zip';
const EDIT_KEY = 'quranExamEdits';

function App(){
  const [query,setQuery]=useState(''); const [selected,setSelected]=useState(null); const [notice,setNotice]=useState('');
  const [edits,setEdits]=useState(()=>{try{return JSON.parse(localStorage.getItem(EDIT_KEY)||'{}')}catch{return {}}});
  const [editMode,setEditMode]=useState(false); const [user,setUser]=useState(null); const [authOpen,setAuthOpen]=useState(false); const [authLoading,setAuthLoading]=useState(false); const [email,setEmail]=useState(''); const [password,setPassword]=useState('');
  const effective=useMemo(()=>data.map(m=>({...m,preview:m.preview.map(q=>edits[q.uid]?{...q,text:edits[q.uid]}:q)})),[edits]);
  const filtered=useMemo(()=>effective.filter(m=>`${m.id} ${m.name}`.includes(query.trim())),[effective,query]);
  const showNotice=(t)=>{setNotice(t); setTimeout(()=>setNotice(''),3200)};

  useEffect(()=>{
    if(!supabaseConfigured) return;
    let active=true;
    loadRemoteEdits();
    supabase.auth.getSession().then(async ({data:{session}})=>{if(active){setUser(session?.user||null)}});
    const {data:{subscription}}=supabase.auth.onAuthStateChange(async (_event,session)=>{if(active){setUser(session?.user||null)}});
    return ()=>{active=false; subscription.unsubscribe()};
  },[]);

  async function loadRemoteEdits(){
    if(!supabase) return;
    const {data:rows,error}=await supabase.from('question_edits').select('uid,text');
    if(error){showNotice('تعذر تحميل تعديلات Supabase؛ تحقق من تشغيل schema.sql');return}
    const remote=Object.fromEntries((rows||[]).map(row=>[row.uid,row.text]));
    setEdits(remote); localStorage.setItem(EDIT_KEY,JSON.stringify(remote));
  }
  const download=(url,label)=>{const a=document.createElement('a');a.href=url;a.download='';document.body.appendChild(a);a.click();a.remove();showNotice(`بدأ تنزيل ${label}`)};
  const updateQuestion=(uid,text)=>{setEdits(prev=>{const next={...prev,[uid]:text};localStorage.setItem(EDIT_KEY,JSON.stringify(next));setSelected(s=>s?{...s,preview:s.preview.map(q=>q.uid===uid?{...q,text}:q)}:s);return next})};
  const persistQuestion=async(uid,text)=>{
    if(!user||!supabase){showNotice('تم الحفظ على هذا الجهاز فقط؛ سجّل دخول المشرف للحفظ المركزي');return}
    const {error}=await supabase.from('question_edits').upsert({uid,text,updated_at:new Date().toISOString(),updated_by:user.id});
    showNotice(error?'تعذر الحفظ في Supabase':'تم حفظ السؤال مركزيًا في Supabase');
  };
  const exportEdits=()=>{const blob=new Blob([JSON.stringify({instructions:'ضع هذا الملف بجانب generate_project.py ثم شغّل python generate_project.py',edits},null,2)],{type:'application/json'});const a=document.createElement('a');a.href=URL.createObjectURL(blob);a.download='quran-exam-edits.json';a.click();URL.revokeObjectURL(a.href);showNotice('تم تصدير التعديلات')};
  const importEdits=(e)=>{const f=e.target.files?.[0];if(!f)return;const r=new FileReader();r.onload=()=>{try{const x=JSON.parse(r.result);const next=x.edits||x;setEdits(next);localStorage.setItem(EDIT_KEY,JSON.stringify(next));showNotice('تم استيراد التعديلات محليًا؛ احفظ كل سؤال لتزامنه مع Supabase')}catch{showNotice('تعذر قراءة ملف التعديلات')}};r.readAsText(f)};
  const login=async(e)=>{e.preventDefault();if(!supabase){showNotice('بيانات Supabase غير مضافة إلى بيئة التشغيل');return}setAuthLoading(true);const {data:result,error}=await supabase.auth.signInWithPassword({email:email.trim().toLowerCase(),password});setAuthLoading(false);if(error){showNotice(`خطأ Supabase: ${error.message}`);return}setUser(result.user);setAuthOpen(false);setPassword('');await loadRemoteEdits();showNotice('تم تسجيل دخول المشرف')};
  const logout=async()=>{await supabase?.auth.signOut();setUser(null);setEditMode(false);showNotice('تم تسجيل الخروج')};
  const startEdit=()=>{if(!user){setAuthOpen(true);showNotice('سجّل دخول المشرف أولًا للتعديل');return}setEditMode(!editMode)};
  return <div className="app">
    <header className="topbar"><div className="brand"><div className="brand-mark">۞</div><div><strong>اختبارات القرآن الكريم</strong><span>الحفظ الشفوي • إصدار تعليمي منظم</span></div></div><div className="top-actions"><button className="admin-btn" onClick={()=>user?logout():setAuthOpen(true)}>{user?<><LogOut size={15}/> خروج المشرف</>:<><LockKeyhole size={15}/> دخول المشرف</>}</button><a className="nav-link" href="#models">النماذج <ArrowLeft size={16}/></a></div></header>
    <main>
      <section className="hero"><div className="hero-copy"><div className="eyebrow"><Sparkles size={16}/> أدوات عملية للمحفّظ والممتحن</div><h1>اختبر الحفظ بثقة،<br/><em>واجعل كل جزء حاضرًا.</em></h1><p>خمسة عشر نموذجًا متكاملًا تغطي الأجزاء الثلاثين، مصممة لتكون واضحة في الجلسة وسهلة في الطباعة والتنزيل.</p><div className="hero-actions"><a className="primary" href="#models">استعرض النماذج <ArrowLeft size={18}/></a><button className="secondary" onClick={()=>download(zipUrl,'ملف النماذج الكامل')}><Archive size={18}/> تنزيل الكل ZIP</button></div></div><div className="hero-card"><div className="seal">۞</div><div className="hero-card-title">من البقرة إلى الناس</div><div className="hero-card-text">أسئلة تبدأ من أوائل آيات صحيحة<br/>ومواضع متباعدة داخل كل جزء</div><div className="hero-card-rule"/><div className="hero-card-foot"><span>15 نموذجًا</span><span>1,800 سؤال فريد</span></div></div></section>
      <section className="stats"><div><b>15</b><span>نموذج اختبار</span></div><div><b>30</b><span>جزءًا في كل نموذج</span></div><div><b>90 + 30</b><span>أساسي واحتياطي</span></div><div><b>100%</b><span>قابل للتحرير والتنزيل</span></div></section>
      <section className="section-head" id="models"><div><div className="eyebrow">المكتبة الرقمية</div><h2>اختر نموذجك</h2><p>كل بطاقة مرتبطة بملف Word حقيقي ومعاينة كاملة للمحتوى.</p></div><div className="search"><Search size={18}/><input value={query} onChange={e=>setQuery(e.target.value)} placeholder="ابحث برقم النموذج…" aria-label="البحث في النماذج"/></div></section>
      {filtered.length?<div className="grid">{filtered.map(m=><article className="model-card" key={m.id}><div className="card-top"><span className="model-no">{String(m.id).padStart(2,'0')}</span><span className="ready"><ShieldCheck size={15}/> جاهز</span></div><h3>{m.name}</h3><div className="card-meta"><span><BookOpen size={16}/> {m.parts} جزءًا</span><span><FileText size={16}/> {m.questions} سؤال</span></div><div className="card-breakdown"><span>أساسي <b>{m.basic}</b></span><span>احتياطي <b>{m.reserve}</b></span></div><div className="card-actions"><button className="primary small" onClick={()=>download(m.file,m.name)}><Download size={16}/> Word</button><button className="text-btn" onClick={()=>{setSelected(m);setEditMode(false)}}>عرض وتعديل <ArrowLeft size={15}/></button></div></article>)}</div>:<div className="empty"><Search size={26}/><h3>لم نعثر على نموذج مطابق</h3><p>جرّب البحث برقم من 01 إلى 15.</p></div>}
      <section className="how"><div className="how-intro"><div className="eyebrow">لوحة المشرف</div><h2>تعديل آمن ومركزي</h2><p>بعد تسجيل دخول المشرف، تُحفظ تعديلات الأسئلة في Supabase بدل بقائها على جهاز واحد فقط.</p><div className="editor-tools"><button className="secondary" onClick={exportEdits}><Database size={16}/> تصدير التعديلات</button><label className="secondary"><Upload size={16}/> استيراد التعديلات<input type="file" accept=".json" hidden onChange={importEdits}/></label></div></div><div className="steps"><div><span>01</span><h3>دخول المشرف</h3><p>استخدم حساب Supabase الذي أنشأته للمشرف.</p></div><div><span>02</span><h3>عدّل واحفظ</h3><p>كل سؤال يُحفظ مركزيًا عند مغادرة خانة التعديل.</p></div><div><span>03</span><h3>حدّث Word</h3><p>صدّر JSON وشغّل سكربت التوليد عند اعتماد نسخة الطباعة.</p></div></div></section>
      <section className="source-note"><ShieldCheck size={22}/><div><strong>حالة الربط</strong><p>{supabaseConfigured?'Supabase مهيأ — '+(user?'تم تسجيل دخول المشرف':'بانتظار دخول المشرف'):'Supabase غير مهيأ في بيئة التشغيل'}</p></div><a href="https://tanzil.net/download/" target="_blank">المصدر</a></section>
    </main><footer><span>© اختبارات القرآن الكريم</span><span>صُمّم للمؤسسات التعليمية وحلقات التحفيظ</span></footer>
    {selected&&<div className="modal-backdrop" onClick={()=>setSelected(null)}><div className="modal" onClick={e=>e.stopPropagation()}><button className="close" onClick={()=>setSelected(null)}><X/></button><div className="modal-heading"><span className="model-no">{String(selected.id).padStart(2,'0')}</span><div><div className="eyebrow">معاينة النموذج</div><h2>{selected.name}</h2><p>120 سؤالًا موزعة على الأجزاء الثلاثين — {editMode?'وضع التعديل مفعل':'وضع القراءة'}</p></div></div><div className="modal-actions"><button className="secondary" onClick={startEdit}><Pencil size={16}/> {editMode?'إنهاء التعديل':user?'تعديل الأسئلة':'دخول للتعديل'}</button><button className="secondary" onClick={exportEdits}><Save size={16}/> تصدير JSON</button></div><div className="preview-list">{selected.preview.map((q,i)=><div className={`preview-row ${q.kind==='احتياطي'?'reserve':''}`} key={q.uid}><div><b>الجزء {String(q.juz).padStart(2,'0')}</b><small>{q.kind} • سورة {q.surah}، آية {q.ayah}</small></div>{editMode?<textarea value={q.text} onChange={e=>updateQuestion(q.uid,e.target.value)} onBlur={e=>persistQuestion(q.uid,e.target.value)} aria-label={`تعديل سؤال ${i+1}`}/>:<p>{q.text} …</p>}</div>)}</div><button className="primary" onClick={()=>download(selected.file,selected.name)}><Download size={17}/> تنزيل ملف Word الأصلي</button><p className="edit-hint">تُحفظ التعديلات في Supabase عند تسجيل دخول المشرف. لتحديث Word النهائي، صدّر JSON وضعه بجانب السكربت ثم شغّل <code>python generate_project.py</code>.</p></div></div>}
    {authOpen&&<div className="modal-backdrop" onClick={()=>setAuthOpen(false)}><form className="auth-modal" onClick={e=>e.stopPropagation()} onSubmit={login}><button type="button" className="close" onClick={()=>setAuthOpen(false)}><X/></button><div className="auth-icon"><LockKeyhole/></div><div className="eyebrow">صلاحية المشرف</div><h2>تسجيل دخول المشرف</h2><p>هذا الدخول مخصص لتعديل الأسئلة وحفظها مركزيًا.</p><label>البريد الإلكتروني<input type="email" required value={email} onChange={e=>setEmail(e.target.value)} autoComplete="username" autoCapitalize="none"/></label><label>كلمة المرور<input type="password" required value={password} onChange={e=>setPassword(e.target.value)} autoComplete="current-password"/></label><button className="primary" disabled={authLoading}>{authLoading?'جارٍ التحقق…':<><LogIn size={17}/> دخول آمن</>}</button>{!supabaseConfigured&&<small className="auth-error">لم تتم إضافة متغيرات Supabase إلى بيئة التشغيل.</small>}</form></div>}
    {notice&&<div className="toast">{notice}</div>}
  </div>
}
createRoot(document.getElementById('root')).render(<App/>);
